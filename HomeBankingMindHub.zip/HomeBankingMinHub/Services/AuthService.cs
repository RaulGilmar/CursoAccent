﻿using HomeBankingMindHub.Models;
using HomeBankingMindHub.Repositories;


/* Implementar en la task 8 capa de servicios
 
namespace HomeBankingMindHub.Services
{
  
    public class AuthService : IAuthService
    {
        private IClientRepository _clientRepository;

        public AuthService(IClientRepository clientRepository)
        {
            _clientRepository = clientRepository;
        }
        public async Task<string> Login(Client LoginRequestDTO)
     }
} */