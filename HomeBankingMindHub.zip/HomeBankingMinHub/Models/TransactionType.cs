﻿namespace HomeBankingMindHub.Models
{
    public enum TransactionType
    {
        CREDIT,
        DEBIT
    }
}
