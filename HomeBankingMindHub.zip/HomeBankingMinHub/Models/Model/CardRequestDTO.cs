﻿namespace HomeBankingMindHub.Models.Model
{
    public class CardRequestDTO
    {
        public string Type { get; set; }
        public string Color { get; set; }
    }
}
