﻿namespace HomeBankingMindHub.Models
{
    public enum CardType
    {
        DEBIT,

        CREDIT
    }
}
