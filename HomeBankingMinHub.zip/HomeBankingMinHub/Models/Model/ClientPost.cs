﻿namespace HomeBankingMinHub.Models.Model
{
    public class ClientPost
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
    }
}
